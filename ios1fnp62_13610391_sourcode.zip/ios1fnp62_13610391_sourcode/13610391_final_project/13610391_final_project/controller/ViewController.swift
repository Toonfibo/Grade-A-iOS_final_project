//
//  ViewController.swift
//  13610391_final_project
//
//  Created by ICTMAC on 20/11/2562 BE.
//  Copyright © 2562 ictsillpakorn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

   
    
}

